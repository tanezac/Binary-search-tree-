/*
 * Project 0 -  Binary search tree 
 * p0.c
 * Tan Nguyen
 * ntnhmc@umsystem.edu
 * Feb 7, 2022
 */


#include <stdio.h>
#include <stdlib.h>
#include <unistd.h> 
#include <string.h>
#include "node.h"
#include "buildTree.h"
#include "traversals.h"


void help();

FILE *inputFilePointer;
char *fileName;

int main(int argc, char** argv){
	
	if (argc == 3){
                printf("p0.c: ERROR: BAD INPUT.\n");
		printf("Provide more than one File Name.\n");
		printf("Usage: P0 [filename] \n");	
                printf("Try './p0 -h' for more information.\n");
                return (EXIT_FAILURE);
        }

	int opt;
        while((opt = getopt(argc, argv, "h")) != -1){
        	switch(opt)
        	{
			case 'h':
                		help();
                		exit(EXIT_SUCCESS);
                		break;
			case '?':
				printf("Unknown option: %c\n", opt);
                		break;
            		default:
                		perror("oss.c: error: invalid argument");
                		help();                		
				break;
       		}
        }
	
	//Read from file if argument = 2 and Read from the keyboard
	if (argc == 2){
		const char fileExt[] = ".txt";
		fileName = (char *) malloc(sizeof(argv[1]));		
		strcpy(fileName, argv[1]);
		char inFile[strlen(fileName) + strlen(fileExt)]; // add ".txt" into fileName : fileName.txt
		strcpy(inFile, fileName);
        	strcat(inFile, fileExt);

		inputFilePointer  = fopen(inFile, "r");
		
		// if file error, abort with appropriate message 
        	if(inputFilePointer == NULL){
                	perror("Error: ");
                	printf("%s Cannot be opened \n.", inFile);
                	return(EXIT_FAILURE);
        	}
    	}
    	else {	//Read from Keyboard until EOF, the CTRL + D
        	const char outputFileName[] = "outFile";
        	fileName = (char *) malloc(sizeof(outputFileName));
        	strcpy(fileName, outputFileName);
        	inputFilePointer = stdin;
		
    	}

    	Node *root = buildTree(inputFilePointer);
    	traverseInorder(root, fileName);
    	traversePreorder(root, fileName);
    	traversePostorder(root, fileName);

	fclose(inputFilePointer);
    	free(fileName);
	return EXIT_SUCCESS;
}

// Show how to run the program
void help() {
printf("======================================================================\n");
printf("\t\t\t\tUSAGE\n");
printf("======================================================================\n\n");

//printf("./p0 -h filename\n");
printf("Invoking the solution: ./p0 [options command]\n\n");
printf("The options for program are: \n");
printf("./p0 -h      :Describe how the project should be run\n");
printf("./p0         :Read from the keyboard until simulated keyboard EOF. Enter CTRL + D when you done\n");
printf("./p0 filename:Read from filename\n");
printf("======================================================================\n");
}
